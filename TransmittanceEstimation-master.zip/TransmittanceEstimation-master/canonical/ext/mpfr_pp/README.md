This repository contains a simple C++ wrapper of the mpfr_t
datastructure for simple integration in C++ projects.
