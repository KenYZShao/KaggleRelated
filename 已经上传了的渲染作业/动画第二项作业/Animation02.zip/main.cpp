//Shao had learnt the concepts of this code following Mr.Zhang, I have studied and comprehended and wrote in my own.
#include <stdio.h>
#include <GL/glew.h>
#include <GL/freeglut.h>//Shao marked, freeglut should including libs and place freeglut.dll properly in to the directory of main.cpp of our project
#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include "glm/gtx/vector_angle.hpp"
#include "glm/gtc/type_ptr.hpp"
#include <time.h>
#include "Node.h"
#include<GLFW/glfw3.h>

using namespace glm;

float XAngle = 0;
float YAngle = 0;
glm::vec3 TargetPos = glm::vec3(0.0f, 0.0f, 0.0f);
bool animation_running = false;
float animation_fill = 0.0f;

GLfloat JointCol[] = { 0.8, 0.5, 0.0, 1.0 };
GLfloat NodeCol[] = { 1.0, 0.0, 1.0, 1.0 };
GLfloat TipCol[] = { 0.4,0.8,0.8,1.0 };
GLfloat TargetCol[] = { 1.0f,1.0f,1.0f, 1.0 };

Node* Root;

void DrawNode(Node* nd) {
	glPushMatrix();

	glm::mat4 previous = nd->Mat;//Shao decleared nd 

	if (nd->parent != NULL) {
		nd->Mat = glm::translate(nd->Mat, glm::vec3(0.0f, 0.0f, nd->parent->length));
		nd->Mat = glm::rotate(nd->Mat, nd->rotation.x, glm::vec3(nd->Mat * glm::vec4(1.0f, 0.0f, 0.0f, 0.0f)));
		nd->Mat = glm::rotate(nd->Mat, nd->rotation.y, glm::vec3(nd->Mat * glm::vec4(0.0f, 1.0f, 0.0f, 0.0f)));
		nd->Mat = glm::rotate(nd->Mat, nd->rotation.z, glm::vec3(nd->Mat * glm::vec4(0.0f, 0.0f, 1.0f, 0.0f)));
		nd->Mat = nd->parent->Mat * nd->Mat;
	}
	else {
		nd->Mat = glm::rotate(nd->Mat, nd->rotation.x, glm::vec3(1.0f, 0.0f, 0.0f));
		nd->Mat = glm::rotate(nd->Mat, nd->rotation.y, glm::vec3(0.0f, 1.0f, 0.0f));
		nd->Mat = glm::rotate(nd->Mat, nd->rotation.z, glm::vec3(0.0f, 0.0f, 1.0f));
	}

	glLoadMatrixf(glm::value_ptr(nd->Mat));

	if (nd->parent != NULL) {//Draw Node
		glMaterialfv(GL_FRONT, GL_DIFFUSE, NodeCol);
		glutSolidSphere(0.2f, 32, 32);
	}

	glMaterialfv(GL_FRONT, GL_DIFFUSE, JointCol);//Draw Joint
	GLUquadricObj* q = gluNewQuadric();
	gluCylinder(q, 0.1f, 0.1f, nd->length, 32, 32);
	gluDeleteQuadric(q);

	if (nd->child == NULL) {//Draw tip
		glLoadMatrixf(glm::value_ptr(glm::translate(nd->Mat, glm::vec3(0.0f, 0.0f, nd->length))));
		glMaterialfv(GL_FRONT, GL_DIFFUSE, TipCol);
		gluCylinder(q, 0.2f, 0.0f, 0.5f, 32, 32);
		glPopMatrix();
	}

	if (nd->child != NULL) {
		DrawNode(nd->child);
	}
	nd->Mat = previous;
}



void MainScene() {
	glClearColor(0, 0, 0, 1);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glm::vec3 CameraPos = glm::vec3(0.0f, 0.0f, 0.0f);
	glm::vec3 CameraDir = glm::vec3(0.0f, 1.0f, -25);
	glm::vec3 WorldUp = glm::vec3(0.0f, 1.0f, 0.0f);
	glm::mat4 V = glm::lookAt(CameraDir, CameraPos, WorldUp);
	V = glm::rotate(V, XAngle, glm::vec3(1.0f, 0.0f, 0.0f));
	V = glm::rotate(V, YAngle, glm::vec3(0.0f, 1.0f, 0.0f));
	glm::mat4 P = glm::perspective(100.0f, 1.0f, 1.0f, 100.0f);
	glMatrixMode(GL_PROJECTION);
	glLoadMatrixf(glm::value_ptr(P));
	glMatrixMode(GL_MODELVIEW);
	glm::mat4 M = glm::mat4(1.0f);
	glLoadMatrixf(glm::value_ptr(V * M));

	glPushMatrix();//Draw Target
	glMaterialfv(GL_FRONT, GL_DIFFUSE, TargetCol);
	glLoadMatrixf(glm::value_ptr(glm::translate(M * V, TargetPos)));
	glutSolidSphere(0.3f, 32, 32);
	glPopMatrix();

	Root->Mat = glm::rotate(M * V, -90.0f, glm::vec3(1.0f, 0.0f, 0.0f));

	DrawNode(Root);

	glutSwapBuffers();
}


void CCD(Node* node, vec3 TargetPos, int iterations = 100) {
	while (iterations--) {
		Node* currentNode = node;
		while (currentNode->parent->parent != NULL) {
			vec4 endPosition = currentNode->getEndPosition();
			vec4 startPosition = currentNode->parent->getEndPosition();
			vec3 toTarget = normalize(vec3(TargetPos.x - startPosition.x, TargetPos.y - startPosition.y, TargetPos.z - startPosition.z));
			vec3 toEnd = normalize(vec3(endPosition.x - startPosition.x, endPosition.y - startPosition.y, endPosition.z - startPosition.z));
			float cosine = dot(toEnd, toTarget);//Target with the current angle 
			if (cosine < 0.99) {
				vec3 crossResult = cross(toEnd, toTarget);//get the rotation aixs 
				float angle = glm::angle(toTarget, toEnd);//Include angle 
				quat rotation = normalize(angleAxis(angle, crossResult));//get the quaternion for selecting 
				glm::vec3 euler = glm::eulerAngles(rotation);//rotating 
				currentNode->setRotateAngle(euler.x, euler.y, euler.z);
			}
			currentNode = currentNode->parent;
		}
	}
}

void keyCtro(unsigned char c, int x, int y) {
	if (c == 'q') {
		TargetPos.z -= 0.2f;
		CCD(Root->FindFinalChild(), TargetPos);
	}
	else if (c == '1') {
		TargetPos.z += 0.2f;
		CCD(Root->FindFinalChild(), TargetPos);
	}
	else if (c == '2') {
		TargetPos.y += 0.2f;
		CCD(Root->FindFinalChild(), TargetPos);
	}
	else if (c == '3') {
		TargetPos.y -= 0.2f;
		CCD(Root->FindFinalChild(), TargetPos);
	}
	else if (c == '4') {
		TargetPos.x -= 0.2f;
		CCD(Root->FindFinalChild(), TargetPos);
	}
	else if (c == '5') {
		TargetPos.x += 0.2f;
		CCD(Root->FindFinalChild(), TargetPos);
	}
	else if (c == '6') {
		YAngle += 0.1f;
	}
	else if (c == '7') {
		YAngle -= 0.1f;
	}
	else if (c == '8') {
		XAngle += 0.1f;
	}
	else if (c == '9') {
		XAngle -= 0.1f;
	}
}

int main(int argc, char* argv[]) {

	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(950, 950);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("IK");

	glutIdleFunc(MainScene);
	glutKeyboardFunc(keyCtro);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_DEPTH_TEST);

	Root = new Node(0.0f);

	Root->add(new Node(1))//Add node
		->add(new Node(1))//Add node
		->add(new Node(1))//Add node
		->add(new Node(1))//Add node
		->add(new Node(1));//Add node

	CCD(Root->FindFinalChild(), TargetPos);

	glutMainLoop();

	delete Root;

	return 0;
}