#ifndef NODE_H
#define NODE_H

#include <vector>
#include <algorithm>
#include "glm/glm.hpp"
#include <exception>


class Node {
public:
	Node* parent;
	Node* child;
	float length;
	
	glm::vec3 coordinates;
	glm::mat4 pos;
	glm::mat4 Mat;
	glm::vec3 rotation;
	Node* add(Node* n);

	Node* setRotateAngle(float dx, float dy, float dz);

	

	glm::mat4 getTransMat();

	glm::vec4 getEndPosition();

	Node* FindFinalChild();

	Node(float len);

	~Node();
};

#endif
